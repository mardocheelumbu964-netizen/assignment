import tkinter as tk
from tkinter import messagebox

# Function to update expression in the text entry box
def press(num):
    entry.insert(tk.END, num)

# Function to evaluate the expression
def equalpress():
    try:
        expression = entry.get()
        result = str(eval(expression))
        entry.delete(0, tk.END)
        entry.insert(tk.END, result)
    except Exception:
        messagebox.showerror("Error", "Invalid Input")

# Function to clear the entry box
def clear():
    entry.delete(0, tk.END)

# Create main window
root = tk.Tk()
root.title("Simple Calculator")
root.geometry("300x400")
root.resizable(False, False)

# Entry widget for input/output
entry = tk.Entry(root, font=("Arial", 20), bd=10, insertwidth=2, width=14, borderwidth=4, relief="ridge", justify="right")
entry.grid(row=0, column=0, columnspan=4, pady=20)

# Button layout
buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3)
]

# Create buttons dynamically
for (text, row, col) in buttons:
    if text == "=":
        tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 14), bg="lightblue",
                  command=equalpress).grid(row=row, column=col, sticky="nsew")
    else:
        tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 14),
                  command=lambda t=text: press(t)).grid(row=row, column=col, sticky="nsew")

# Clear button
tk.Button(root, text="C", padx=20, pady=20, font=("Arial", 14), bg="lightcoral", command=clear)\
    .grid(row=5, column=0, columnspan=4, sticky="nsew")

# Adjust row and column weights for resizing
for i in range(6):
    root.rowconfigure(i, weight=1)
for j in range(4):
    root.columnconfigure(j, weight=1)

# Run the application
root.mainloop()
